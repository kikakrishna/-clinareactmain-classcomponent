import * as React from 'react';
import { useEffect } from 'react';
import Navbar from './Navbar'
import Api, { apiClient } from '../Services/Api';

const { useState } = React;


// function Dashboard() {
//     const [open, setOpen] = useState('');


//     // componentDidMount = () =>{
//     //     var comment = JSON.parse(localStorage.getItem('userName'));
//     //     setOpen({ comment })
//     // }

//     useEffect(() => {
//         var comment = JSON.parse(localStorage.getItem('userName'));
//         setOpen({ comment })
//         console.log(comment)
//         console.log("comment retrieve : ", comment)
//     }, []);

//     // const comment = comment
//     return (

//         <div>
//             Hai
//             <p>{open} </p>
//         </div>
//     )

// }



class Dashboardpage extends React.Component {


  constructor(props) {
    super(props)

    this.state = {
      email: '',
      password: '',
      iconOff: false,
      isRevealPwd: false,
      data: [],
    };

    // this.routeChange = this.routeChange.bind(this);
    // this.initialState = this.state;

  }
  //let userName = {localStorage.getItem('username')} 
  componentDidMount() {
    console.log("dashboard");
    var comment = JSON.parse(localStorage.getItem('currentUser'));

    console.log("comment retrieve : ", comment);

    console.log(comment.userName)
    this.setState({ data: comment.userName })

    // Doctor-API
    apiClient()
      .get("/DropDown/Doctor", {
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${comment.token}` },

      }).then((r) => {
        console.log("analysticsresponse" + JSON.stringify(r.data.isError));
      });

    // Domain-API
    apiClient()
      .get("/Clinic/domain", {
        headers: { "Content-Type": "application/json" },
      }).then((r) => {

        console.log("analysticsresponse" + JSON.stringify(r.data.isError));

      });
  }


  //localStorage.getItem('currentUser', JSON.stringify(r.data.responseMessage.userName));
  //const data = JSON.stringify(localStorage.getItem('data'))
  render() {
    return (

      <div className='dashboardmain'>


        <div className=''>
          <Navbar />
          <h4>Welcome {this.state.data}!</h4>
        </div>


      </div >
    )
  }
}

export default (Dashboardpage);