import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Stack from '@mui/material/Stack';
import clina from './Assets/clina-blue.webp'

const darkTheme = createTheme({
    palette: {

        primary: {
            main: '#273F57',
        },
    },
});


export default function Curenavbar() {
    return (
        <div>
            <Stack spacing={2} sx={{ flexGrow: 1 }}>
                <ThemeProvider theme={darkTheme}>

                    <Box sx={{ flexGrow: 1 }}>
                        <AppBar position="static">
                            <Toolbar>
                                <IconButton
                                    size="large"
                                    edge="start"
                                    color="inherit"
                                    aria-label="menu"
                                    sx={{ mr: 2 }}
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="48"
                                        height="48"
                                        fill="none"
                                        viewBox="0 0 48 48"
                                    >
                                        <g clipPath="url(#clip0_48_103)">
                                            <path
                                                fill="#fff"
                                                d="M43.725 12.469a4.522 4.522 0 01-.534.455l-8.115-8.115c.139-.19.29-.37.454-.535A2.501 2.501 0 0035.524.73a2.504 2.504 0 00-3.536 0c-3.4 3.4-3.531 8.921-3.192 12.433-3.512-.339-9.035-.207-12.44 3.198-3.4 3.4-3.53 8.923-3.192 12.433-3.51-.339-9.032-.207-12.432 3.192A2.504 2.504 0 002.51 36.26c.59 0 1.172-.216 1.641-.627l8.217 8.217a2.481 2.481 0 00.109 3.418 2.499 2.499 0 003.536 0c3.388-3.387 3.523-8.918 3.19-12.434.76.072 1.61.123 2.516.123 3.288 0 7.263-.658 9.919-3.314 3.392-3.392 3.53-8.922 3.197-12.439 3.511.339 9.034.209 12.434-3.192a2.504 2.504 0 00-3.543-3.543zm-1.875 1.17a9.574 9.574 0 01-2.02.518l-5.992-5.992c.107-.7.27-1.388.518-2.02l7.494 7.494zm-7.907.415a22.982 22.982 0 01-.27-3.998l4.261 4.263a23.317 23.317 0 01-3.99-.265zM33.016 1.76a1.049 1.049 0 011.48 0c.411.411.414 1.077.006 1.485-2.71 2.71-2.429 7.893-2.074 10.512a28.51 28.51 0 00-2.154-.413c-.35-3.213-.345-8.497 2.742-11.584zM13.25 42.675L5.327 34.75a7.368 7.368 0 011.832-.704l6.799 6.798a7.35 7.35 0 01-.708 1.83zm.806-8.73c.162 1.04.4 3.085.2 5.142L8.92 33.75c2.055-.198 4.096.035 5.136.195zm-12.295.55a1.048 1.048 0 010-1.48c2.828-2.829 7.623-3.172 11.581-2.742.165 1.121.365 1.982.416 2.157-2.62-.35-7.814-.627-10.512 2.071a1.053 1.053 0 01-1.485-.006zm18.978-15.243l8.008 8.008c-.428.694-.849 1.082-1.485 1.482l-8.005-8.006c.397-.631.787-1.056 1.482-1.484zm3.901-1.131l5.238 5.247c-.083.881-.243 1.72-.491 2.475l-7.23-7.23c.757-.25 1.599-.409 2.483-.492zm5.044.194c.151.987.25 2.03.268 3.068l-3.33-3.334c1.037.018 2.077.116 3.062.266zM23.367 29.89l-5.258-5.258c.077-.853.234-1.704.496-2.49l7.253 7.253a11.09 11.09 0 01-2.49.495zm-1.993.064a24.036 24.036 0 01-3.06-.267 24.182 24.182 0 01-.266-3.06l3.326 3.327zm9.234.661c-3.074 3.074-8.36 3.084-11.581 2.741-.079-.533-.299-1.758-.417-2.156 3.431.459 8.064.38 10.512-2.07 2.677-2.677 2.414-7.886 2.074-10.515.31.08 1.209.266 2.16.41.343 3.22.331 8.51-2.748 11.59zM46.24 14.983c-3.426 3.426-10.07 3.318-14.67 2.224-3.72-.972-9.933-1.095-12.698 1.67-2.73 2.729-2.574 8.422-1.783 12.194.102.486.351 1.278.573 3.033.398 3.134.58 8.878-2.678 12.134-.41.41-1.07.41-1.479 0a1.047 1.047 0 01-.006-1.485c3.154-3.154 2.256-9.651 1.906-11.568a.684.684 0 00-.019-.079c-.457-2.496-.045.41-.677-3.582-.404-3.127-.593-8.862 2.677-12.133 3.275-3.275 9.011-3.088 12.139-2.684 2.084.272 2.285.444 3.664.697 1.921.347 8.43 1.231 11.566-1.907a1.048 1.048 0 011.485.006 1.048 1.048 0 010 1.48z"
                                            ></path>
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_48_103">
                                                <path fill="#fff" d="M0 0H48V48H0z"></path>
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </IconButton>
                                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                    KRAS
                                </Typography>
                                {/* <Button color="inherit">Login</Button> */}
                            </Toolbar>
                            <div className='navdisablecontent'>
                                <p><span className='navdisable'>Ensemble:</span> ENSG00000133703 | <span className='navdisable'>UniProt:</span> P01116 | <span className='navdisable'>Genecards:</span> KRAS | <span className='navdisable'>HGNC:</span> KRAS | <span className='navdisable'>Project Score:</span> SIDG13960</p>
                            </div>

                        </AppBar>
                    </Box>

                </ThemeProvider>
            </Stack>

        </div>

    );
}