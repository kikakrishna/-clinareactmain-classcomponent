import * as React from 'react';
import Button from '@mui/material/Button';
import Loginpopup from './Login-popup';



class Popup extends React.Component {
    render() {
        return (
            <div className='popup'>
                <div >
                    <Loginpopup />
                    {/* <h1>{this.props.text}</h1> */}
                    <div className='closebtn'>
                        <Button onClick={this.props.closePopup}>Close</Button>

                    </div>

                </div>
            </div>
        );
    }
}


class Login extends React.Component {

    constructor() {
        super();
        this.state = {
            showPopup: false
        };
    }
    togglePopup() {
        console.log('fefef')
        this.setState({
            showPopup: !this.state.showPopup
        });
    }

    render() {
        return (
            <div>
                <nav>
                    <div className='loginnav'>
                        <Button onClick={this.togglePopup.bind(this)}>Login</Button>

                    </div>

                    {this.state.showPopup ?
                        <Popup
                            text='Close Me'
                            closePopup={this.togglePopup.bind(this)}
                        />
                        : null
                    }

                </nav>

            </div>
        )
    }
}

export default (Popup);