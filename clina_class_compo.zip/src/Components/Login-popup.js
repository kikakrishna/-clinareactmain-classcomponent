// import * as React from 'react';
// import Button from '@mui/material/Button';
// // import darkScrollbar from '@mui/material/darkScrollbar';
// // import CssBaseline from '@mui/material/CssBaseline';
// // import DeleteIcon from '@mui/icons-material/Delete';
// // import IconButton from '@mui/material/IconButton';
// // import Tooltip from '@mui/material/Tooltip';
// import styled from 'styled-components';

// const Input = styled.input`
//   padding: 0.5em;
//   margin: 0.5em;
//   color: ${props => props.inputColor || "palevioletred"};
//   background: papayawhip;
//   border: none;
//   border-radius: 3px;
// `;


// class Navbar extends React.Component {
//     render() {
//         return (


//             <div style={{ backgroundColor: "#fff" }}>

//                 <Button>Login</Button>

//             </div>



//         )
//     }
// }

// export default (Navbar);



import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import Api, { apiClient } from '../Services/Api';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { Suspense } from 'react';
import Login from './Login';
import whitelogo from './Assets/clina-whitelogo.webp'
import playstore from './Assets/playstore.webp'
import clinicicon from './Assets/clinic-large.webp'
// import { useNavigate } from 'react-router-dom';
import { useHistory } from "react-router-dom";
function Copyright(props) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      {'Copyright © '}
      <Link color="inherit" href="https://mui.com/">
        Your Website
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const theme = createTheme({
  typography: {
    h1: {
      textalign: "center",
      fontSize: 18,
      fontWeight: 600,
      color: "#324A7B",
      marginTop: "5px",
    },

  },
});
export default function Loginpopup() {
  const { useState } = React;
  const [open, setOpen] = React.useState(false);
  const [resdata, setresdata] = useState('');
  const [variantt, setvariantt] = useState('');
  // const navigate = useNavigate();
  // const history = useHistory();
  // const home = () => {
  //     history.push("/");
  // }
  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log(data)
    console.log({
      email: data.get('email'),
      password: data.get('password'),
    });


    var loginReg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    // var passwordReg = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8, 32}$/;
    if (data.get('email').trim() !== '') {
      if (loginReg.test(data.get('email'))) {
        if (data.get('password').trim() !== '') {
          if (data.get('password').length > 4) {
            // console.log('calling')
            // this.login()
          } else {
            alert("Enter the valid password");
          }
        } else {
          alert("Enter Your Password");
        }
      }
      else {
        alert("Enter your valid Email");
      }
    } else {
      alert("Please Enter Your Email");
    }
    // async{
    //       const result = await apiClient({
    //         url: "Api/Insurance/GetInsuranceProvider",
    //         method: "Get",
    //       });

    //     }
    if (data.get('password') !== "" && data.get('email') !== "") {
      let Data = {
        Username: data.get('email'),
        Password: data.get('password'),
      }

      apiClient()
        .post("/Login", Data, {
          headers: { "Content-Type": "application/json" },
        }).then((r) => {
          console.log("analysticsresponse" + JSON.stringify(r.data.isError));

          localStorage.setItem('currentUser', JSON.stringify(r.data.responseMessage));
          localStorage.setItem('userName', JSON.stringify(r.data.responseMessage.userName));

          // state.data: r.data.responseData
          // if (r.data !== null) {
          //   setresdata(r.data.errorMessage);
          //   // setresdata(r.data.responseMessage.userName);
          // } else {
          //   setresdata(r.data.responseMessage.userName);
          //   // setresdata(r.data.errorMessage);
          // }
          if (r.data.isError == false) {
            console.log("false---->")
            setresdata(r.data.responseMessage.userName);

            setvariantt("success")
            // navigate('/Curedashboard')
            // history.push("/Curedashboard");

          } else {
            console.log("true---->")
            setresdata(r.data.errorMessage);
            setvariantt("warning")
          }
          //setresdata(r.data.responseMessage.userName);


        });

      setOpen(true);
      console.log("data-------->" + resdata)

    };
  }

  const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

  const [values, setValues] = React.useState({
    password: "",
    showPassword: false
  });



  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  const handleChange = (prop) => event => {
    console.log("event")
    setValues({ ...values, [prop]: event.target.value });

  };


  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
    console.log("hehdehidfh")
  };

  const handleMouseDownPassword = event => {
    event.preventDefault();
  };
  const OtherComponent = React.lazy(() => import('./Login'));
  //const AnotherComponent = React.lazy(() => import('./AnotherComponent'));

  //--------------------MUI-Email-Validation------------------------------------------
  const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  const [errorText, setErrorText] = React.useState();
  const [phone, setPhone] = React.useState();
  //const [Email, setEmail] = useState('');
  const handleemail = (event) => {
    if (event.target.value.match(emailRegex)) {
      setErrorText("");
      //setPhone(event.target.value);
    } else {
      setErrorText("invalid format");
    }
  };
  //-------------------------------------------------------------------------
  return (

    <div className='popupaling'>
      <div className='leftbg'>

        <img src={whitelogo} className="clinawhitelogo" />
        <h3>Anytime, Anywhere Healthcare Delivery!</h3>
        <p>Customizable telehealth solution for your clinical practice</p>

        <div className='playstorecontent'>
          <p>Also available in</p>
          <img src={playstore} className="playstorelogo" />
        </div>
      </div>


      <div className='popup_inner'>
        <ThemeProvider theme={theme}>
          <Container component="main" maxWidth="xs">
            <CssBaseline />
            <Box
              sx={{
                marginTop: 8,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              {/* <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                
                <LockOutlinedIcon />
              </Avatar> */}
              <img src={clinicicon} className='clinicavatar' />
              <Typography component="h1" variant="h1">
                Clinic/Doctor Login
              </Typography>
              <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                <Snackbar open={open} autoHideDuration={2000} onClose={handleClose} maxSnack={3} >
                  <Alert onClose={handleClose} severity={variantt} sx={{ width: '100%' }}>
                    {resdata}
                  </Alert>
                  {/* <Alert onClose={handleClose} severity="warning" sx={{ width: '100%' }}>
                {resdata}
              </Alert> */}
                </Snackbar>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  autoFocus
                  helperText={errorText}
                  error={errorText}
                  onChange={handleemail}
                  value={phone}
                />
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type={values.showPassword ? "text" : "password"}
                  id="password"
                  onChange={handleChange}
                  autoComplete="current-password"
                //helperText="Incorrect entry."
                />

                <div className='visibleicon'>
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge="end"
                    >
                      {values.showPassword ? <Visibility /> : <VisibilityOff />}
                    </IconButton>
                  </InputAdornment>
                </div>

                {/* <FormControlLabel
                  control={<Checkbox value="remember" color="primary" />}
                  label="Remember me"
                /> */}
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{ mt: 3, mb: 2 }}
                >
                  Sign In
                </Button>
                <Grid container>
                  <Grid item xs>
                    <Link href="#" variant="body2">
                      Forgot password?
                    </Link>
                  </Grid>
                  {/* <Grid item>
                    <Link href="#" variant="body2">
                      {"Don't have an account? Sign Up"}
                    </Link>
                  </Grid> */}
                </Grid>
              </Box>
            </Box>
            {/* <Copyright sx={{ mt: 8, mb: 4 }} /> */}
          </Container>
        </ThemeProvider>
      </div>


      {/* <Suspense fallback={<div>Loading...</div>}>
        <section>
          <Login />
         
        </section>
      </Suspense> */}
    </div>

  );
}