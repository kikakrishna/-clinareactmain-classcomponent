import * as React from 'react';
import Button from '@mui/material/Button';
// import darkScrollbar from '@mui/material/darkScrollbar';
// import CssBaseline from '@mui/material/CssBaseline';
// import DeleteIcon from '@mui/icons-material/Delete';
// import IconButton from '@mui/material/IconButton';
// import Tooltip from '@mui/material/Tooltip';
// import styled from 'styled-components';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';
import Modal from "react-modal";


const customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)"
    }
  };
class Login extends React.Component {

    constructor() {
        super();
    
        this.state = {
          modalIsOpen: false
        };
    
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
      }
    
      openModal() {
        this.setState({ modalIsOpen: true });
      }
    
      afterOpenModal() {
        // references are now sync'd and can be accessed.
        this.subtitle.style.color = "#f00";
      }
    
      closeModal() {
        this.setState({ modalIsOpen: false });
      }

    render() {
        return (
            <div>
                <nav>
                    <div style={{ backgroundColor: "#fff" }}>

                        <Button>Login</Button>

                    </div>
                </nav>

             

                <button onClick={this.openModal}>
                Have an account?<span>Login</span>
              </button>
              <Modal
                isOpen={this.state.modalIsOpen}
                onAfterOpen={this.afterOpenModal}
                onRequestClose={this.closeModal}
                style={customStyles}
                contentLabel="Example Modal"
              >
                <h2 ref={subtitle => (this.subtitle = subtitle)}>Login</h2>
                <button onClick={this.closeModal}>close</button>
                <div>I am a modal</div>
                <form>
                  <input />
                </form>
              </Modal>
            </div>



        )
    }
}

export default (Login);

//--------------------------------------------------------------------------------



// const Input = styled.input`
//   padding: 0.5em;
//   margin: 0.5em;
//   color: ${props => props.inputColor || "palevioletred"};
//   background: papayawhip;
//   border: none;
//   border-radius: 3px;
// `;

{/* <Tooltip title="Delete">
                    <IconButton>
                        <DeleteIcon />
                    </IconButton>
                </Tooltip>
                <Input defaultValue="@probablyup" type="text" />
                <Input defaultValue="@geelen" type="text" /> */}

                  // <div>
            //       <Button variant="contained">Hello World</Button>
            //       <h2>Hai</h2>
            // </div>
            //     <React.Fragment>
            //     <CssBaseline />
            //     {/* The rest of your application */}
            //   </React.Fragment>