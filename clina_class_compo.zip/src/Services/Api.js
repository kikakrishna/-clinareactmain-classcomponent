import axios from "axios";


// export const BASEURL='https://xclinic.kindclinic.online/telehealthapi/api/'

export const BASEURL='https://xclinic.latlontech.com/telehealthapi/api/'




export const apiClient = () => {
	const axiosInstance = axios.create({
        baseURL: BASEURL,
		responseType: "json",
	});
    // axiosInstance.defaults.headers.post['Access-Control-Allow-Origin'] = '*';
	return axiosInstance;
};